import pandas as pd
import sys
import zipfile

# Load the CSV file with correct settings, cos data has different values. !!!! USE YOUR OWN WAY OF FILE PATH 
file_path = "/Users/kseniianazarova/Desktop/nexford/modul2/Total.csv"
df = pd.read_csv(file_path, dtype=str, low_memory=False)  # Allow to read all columns as string to avoid dtype errors

# Trim column names to avoid hidden spaces
df.columns = df.columns.str.strip()

# If you want to check column names, you can use next command, just need uncomment it:
#print("Columns in CSV:", df.columns.tolist())

column_salary = "TotalPayBenefits"
column_name = "EmployeeName"

# Convert salary data to numeric, replacing errors with NaN
df[column_salary] = pd.to_numeric(df[column_salary], errors="coerce")

# Remove rows with missing salary data
df = df.dropna(subset=[column_salary])

print("We are starting group processing...")

# Convert DataFrame into a dictionary
employee_dict = {name: group.drop(columns=[column_name]).to_dict(orient="records") 
                 for name, group in df.groupby(column_name)}
df[column_name] = df[column_name].fillna("")

print("The group processing is finished.")

# Aply function to fetch employee details
def get_employee_details(name):
    
    column_name = "EmployeeName"

    if column_name not in df.columns:
        return f"Error: Column '{column_name}' not found in CSV."

    employee_data = df[df[column_name].str.contains(name, case=False, na=False)]
    
    if not employee_data.empty:
        return employee_data
    else:
        return "Employee not found. Change your input and try again."

# Function to get salary statistics
def salary_statistics():
    salaries = df[column_salary].tolist()
    if not salaries:
        return "No salary data available."
    
    stats = {
        "Total count of Employees": len(salaries),
        "Minimum Salary, $": min(salaries),
        "Maximum Salary, $": max(salaries),
        "Average Salary, $": round(sum(salaries) / len(salaries), 2)
    }
    
    return stats

#Export to CSV and save like a .zip
def export_employee_details(employee_data, employee_name):
    folder_name = "Employee Profile"
    zip_file_name = f"{folder_name}.zip"
    csv_file_name = f"{employee_name.replace(' ', '_')}.csv"
    # Save to CSV
    employee_data.to_csv(file_path, index=False)
    # Create a zip file and add the CSV
    with zipfile.ZipFile(zip_file_name, 'w', zipfile.ZIP_DEFLATED) as zipf:
        zipf.write(file_path, arcname=csv_file_name)
    print(f"Employee data results exported successfully to {zip_file_name}.")
    
# Usage/employee search
print("Enter 'Name' or 'Surname' of employee to check the details: ", end="", flush=True)
sys.stdout.flush()  # Anyway show the row bofore the input, just in case
employee_name = input()
result = get_employee_details(employee_name)


#Display of the result
if isinstance(result, str):
    print(result)
else:
    print(result.to_string(index=False))  # Print without index
    export_employee_details(result, employee_name)  # Export to CSV and ZIP
if result is None:
    print("Employee not found. Change your input and try again.")

print("\nSalary Statistics for all company:")
print(salary_statistics())
