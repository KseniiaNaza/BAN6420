# Assignment_Salary_Function 

This script by Phyton allows to order data of employees by name, shows info about salary statistics for the current company, uploads a zip file with the CSV results of the order.

This script by R allows the unzip of the file from a followed directory and shows the results of the unarchived CSV file.


Python
Python 3.x should be installed
Steps:
1) Save the script as "SalaryFunction.py"
2) Save the Total.csv file
3) Open the "SalaryFunction.py" and add your directory of Total.csv file
4) Run ```sh python SalaryFunction.py ```
5) Type the name in the request (like example 'Lee').
6) A table with employees' details by added name will be provided on the screen. Salary statistics will be provided on the screen. Employee_Profile.zip file with the results of the search will be uploaded in the directory. 


R
R (4.x+) should be installed
Steps:
1) Save the script "unzip.R"
2) Open the unzip.R and update directories. 
2) Run source("unzip.R")
3) Employee_Profile.zip will be unzipped, and the table of the CSV file will be shown on the screen. 

