# ADD directory to zip and directory to unzipped file
zip_file <- "/Users/kseniianazarova/Desktop/R2/Employee_Profile.zip" # directory to zip
unzip_dir <- "/Users/kseniianazarova/Desktop/R2" # directory to unzipped file

# Unzip files
unzip(zip_file, exdir = unzip_dir, junkpaths = TRUE)
Sys.sleep(2) # Waiting to be sure if files unzip
files <- list.files(unzip_dir, full.names = TRUE, recursive = TRUE)
print(files)

# List of files in unzip directory
files <- list.files(unzip_dir, full.names = TRUE, recursive = TRUE)
print(files)

# Read and show parameters of unzipped csv
library(readr)

for (file in files) {
    if (grepl("\\.csv$", file)) {
        data <- read_csv(file)
        print(data)
    }
}
