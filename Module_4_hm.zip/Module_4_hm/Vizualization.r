# Upload necessary libraries
install.packages("ggplot2", dependencies = TRUE)
install.packages("dplyr", dependencies = TRUE)
install.packages("readr", dependencies = TRUE)

library(ggplot2)
library(dplyr)
library(readr)

# Upload the file
# USE YOUR OWN WAY OF FILE PATH !!!!
file_path <- "/Users/kseniianazarova/Desktop/nexford/Module4/Module4asses/Netflix_shows_movies.csv" # Add your path
df <- read_csv(file_path)

# Check the data about "release_year"
if ("release_year" %in% colnames(df)) {
    # Creating the graff
    p <- ggplot(df, aes(x = release_year)) +
        geom_histogram(binwidth = 5, fill = "pink", color = "purple", alpha = 0.7) +
        labs(
            title = "Vizualization Movies and TV-shows vs Year of the release",
            x = "Year of the release",
            y = "Count"
        ) +
        theme_minimal()

    # Vizualization Movies and TV-shows vs Year of the release
    print(p)

    if (interactive()) {
        dev.new()
        print(p)
    }
} else {
    print("The info about 'Year of the release' doesn't exist.")
}
