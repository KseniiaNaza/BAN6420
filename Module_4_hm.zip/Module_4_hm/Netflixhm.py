import zipfile
import os
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px

# Way to archive
# USE YOUR OWN WAY OF FILE PATH !!!! 
zip_path = "/Users/kseniianazarova/Desktop/nexford/Module4/Module4asses/netflix_data.csv.zip"
extract_path = "/Users/kseniianazarova/Desktop/nexford/Module4/Module4asses"

# Uppack the archive
with zipfile.ZipFile(zip_path, 'r') as zip_ref:
    zip_ref.extractall(extract_path)
    
# Rename the file
old_filename = os.path.join(extract_path, 'netflix_data.csv')  # New name after unpack
new_filename = os.path.join(extract_path, 'Netflix_shows_movies.csv')

if os.path.exists(old_filename):
    os.rename(old_filename, new_filename)
    print(f'Success, file has new name in the path - {new_filename}')
else:
    print('Error, ups, something went wrong. Try again.')
    

# Data cleaning (deleting the raws with empty values)
if os.path.exists(new_filename):
    df = pd.read_csv(new_filename)
    # Check statistic of empty values before deleting
    print("\nStatistic of empty values before deleting:")
    print(df.isnull().sum())
    df.dropna(inplace=True)  # Deleting the raws with empty values
    df.to_csv(new_filename, index=False)
    print('The raws with empty values were deleted. The File is updated successfully.')
    
   # Check the data
    print("\nData in the file:")
    print(df.describe(include='all'))
    
    # Extra analysis: values by columns
    if 'type' in df.columns:
        type_counts = df['type'].value_counts()
        print("\nOrdering by content type in the file:")
        print(type_counts)
        
        # Vizualization Movies and TV-shows vs Year of the release
        plt.figure(figsize=(8, 5))
        type_counts.plot(kind='bar', title='Ordering by content')
        plt.xlabel('Type of the content')
        plt.ylabel('Total count')
        plt.xticks(rotation=50)
        plt.show()
    
    if 'release_year' in df.columns:
        plt.figure(figsize=(15, 7))
        df['release_year'].hist(bins=20, edgecolor='black')
        plt.title('Vizualization: Movies and TV-shows vs Year of the release')
        plt.xlabel('Year of the release')
        plt.ylabel('Total count')
        plt.grid(axis='y', linestyle='--', alpha=0.7)
        plt.show()
    
    # Vizualization The most popular genre
    if 'listed_in' in df.columns:
        genre_counts = df['listed_in'].str.split(', ').explode().value_counts().head(10)
        plt.figure(figsize=(15, 7))
        sns.barplot(x=genre_counts.values, y=genre_counts.index, palette='inferno')
        plt.title('Top-10 the most popular genres')
        plt.xlabel('Count')
        plt.ylabel('Genre')
        plt.show()
    
    # Vizualization by Rates 
    if 'rating' in df.columns:
        plt.figure(figsize=(15, 7))
        sns.countplot(y=df['rating'], order=df['rating'].value_counts().index, palette='plasma')
        plt.title('Vizualization by Rates')
        plt.xlabel('Count')
        plt.ylabel('Rate')
        plt.show()
    
    # Vizualization map by countries and dependences on movies and tv-shows
    if 'country' in df.columns:
        country_counts = df['country'].str.split(', ').explode().value_counts().reset_index()
        country_counts.columns = ['country', 'count']
        fig = px.choropleth(
            country_counts,
            locations='country',
            locationmode='country names',
            color='count',
            title='Vizualization map: Countries and dependences on movies and tv-shows',
            labels={'count': 'count'}
        )
        fig.show()
