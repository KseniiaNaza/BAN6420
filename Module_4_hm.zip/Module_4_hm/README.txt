# Assignment_Netxlix_visualization

This script by Phyton allows to the unzip of the file from a followed directory and order data of Nerflix content by count of movies and TV-shows, release date, country, rates. 
Includes also vizualization of dependences based on Movies and TV-shows vs Year of the release, The most popular genre, Rates and also the Vizualization by map by countries and dependences on movies and tv-shows.

This script by R allows the install necessary libraries to show the vizualization based on Movies and TV-shows vs Year of the release.

Python
Python 3.x should be installed.
Libraries pandas, matplotlib, seaborn, plotly should be installed. (by pip install NAME_OF_LIBRARY)
Steps:
1) Save the script as "Netflixhm.py"
2) Save the netflix_data.csv.zip file
3) Open the ""Netflixhm.py" and add your directory of netflix_data.csv.zip file
4) Add also derictory, where you'd like to save unzipped (by phyton) file
5) Run ```sh python Netflixhm.py ```
6) A table with statistic details will be provided on the screen.

R
R (4.x+) should be installed
Steps:
1) Save the script as "Vizualization.R"
2) Open the Vizualization.R and update directory of unzipped (by phyton) file
3) Run source("Vizualization.R")
4) A table with statistic based on Movies and TV-shows vs Year of the release will be provided on the screen.