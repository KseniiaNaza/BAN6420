set.seed(123)  # For reproducibility

# Create a list of workers
total_workers <- 400
workers <- vector("list", total_workers)  

create_workers <- function() {
  for (i in 1:total_workers) {
    worker <- list()
    worker$id <- i
    worker$name <- paste("Worker", i, sep="_")
    worker$gender <- sample(c("male", "female"), 1)
    worker$salary <- sample(5000:35000, 1)  
    
    # Assign levels
    worker$level <- "General"
    if (worker$salary > 10000 & worker$salary < 20000) {
      worker$level <- "A1"
    }
    if (worker$salary > 7500 & worker$salary < 30000 & worker$gender == "female") {
      worker$level <- "A5-F"  
    }
    
    workers[[i]] <<- worker  
  }
}

generate_payment_slips <- function() {
  if (length(workers) == 0 || all(sapply(workers, is.null))) {
    cat("No workers found. Run create_workers() first.\n")
    return()
  }
  
  print(workers)  # Print the full list of workers
  
  for (worker in workers) {
    if (is.null(worker)) next  # Skip if worker is not properly assigned
    cat("\nPayment Slip\n")
    cat("Worker ID:", worker$id, "\n")
    cat("Name:", worker$name, "\n")
    cat("Gender:", worker$gender, "\n")
    cat("Salary: $", worker$salary, "\n")
    cat("Employee Level:", worker$level, "\n")
    cat("-------------------\n")
  }
}

# Main execution
tryCatch({
  create_workers()
  generate_payment_slips()
}, error = function(e) {
  cat("Something went wrong... maybe check your values?\n")
})

