#The program should accomplish the following tasks:

#Use variables to create a list of workers dynamically (at least 400 workers).
#Implement the following conditional statements within the for loop:
#If the salary is greater than $10,000 and less than $20,000, assign the Employee level as "A1."
#If the salary is greater than $7,500 and less than $30,000 and the employee is female, set the Employee level as "A5-F."

import random

workers = []

def create_workers():
    for i in range(1, 401):  # 1 to 400 inclusive
        worker = {}
        worker["id"] = i
        worker["name"] = "Worker_" + str(i)  
        worker["gender"] = random.choice(["male", "female"])
        worker["salary"] = random.randint(5000, 35000)

        # Assigning levels
        worker["level"] = "General"
        if worker["salary"] > 10000 and worker["salary"] < 20000:
            worker["level"] = "A1"
        if worker["salary"] > 7500 and worker["salary"] < 30000 and worker["gender"] == "female":
            worker["level"] = "A5-F"  
        
        workers.append(worker)

def generate_payment_slips():
    for worker in workers:
        print("\nPayment Slip")  
        print("Worker ID:", worker["id"])  
        print("Name:", worker["name"])
        print("Gender:", worker["gender"])
        print("Salary: $" + str(worker["salary"]))  
        print("Employee Level:", worker["level"])
        print("-------------------")

if __name__ == "__main__":
    try:
        create_workers()
        generate_payment_slips()
    except Exception as e:
        print("Something went wrong... maybe check your values?")
