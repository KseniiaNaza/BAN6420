from datetime import datetime

class Payment:
    def __init__(self, policyholder, amount):
        self.policyholder = policyholder
        self.amount = amount
        self.paid = False

    def process_payment(self):
        if not self.paid:
            self.paid = True
            print(f"The policiholder {self.policyholder.name} payed {self.amount} $.")
        else:
            print("The payment was recieved before.")

    def send_reminder(self):
        penalty_fee = self.fee_calculator()
        if penalty_fee > 0:
            reminder_notification = f"Reminder: {self.policyholder.name}, You have an unpaid amount {self.amount} $."
            reminder_notification += f"Penalty was applied since 01/01/2025: {penalty_fee} $. New total unpaid amount: {self.amount + penalty_fee} $"
            print(reminder_notification)
        elif not self.policyholder.active:
            print(f"Reminder: Account axpired. {self.policyholder.name} your Insurance product susspended. For renew the product, please send the request to support.")

    def apply_penalty(self):
        penalty = self.fee_calculator()
        self.amount += penalty
        print(f"Fines were added for {self.policyholder.name}. New balance: {self.amount} $.")
    
    def fee_calculator(self):
        fee_start_date = datetime.strptime("01/01/2025", "%d/%m/%Y")
        if not self.policyholder.active and self.policyholder.registration_date < fee_start_date:
            return self.amount * 0.05
        return 0
    
    def check_fee(self):
        fee = self.fee_calculator()
        if fee > 0:
            print(f"Reminder: {self.policyholder.name}, penalty has been added due to an expired account since 01/01/2025. Penalty amount: {fee} $. New balance: {self.amount + fee} $.")