# Assignment_Policy Management System for an Insurance Company 

This script by Phyton allows to show of data of insurance company customers, info about their account state, their payments, type of insurance policy.
In case, if account of customer was expired, the script will show this info with details of possible fee. 

Python 3.x should be installed
Steps:
1) Save the scripts: "Insurance_info.py", "Policyholder.py", "PolicyProduct.py", "Payment.py".
2) Open "Insurance_info.py"
3) In the "Insurance.py" there are pre-added parameters of customers - Dart Wayder, Harry Potter, Tom Cat. You can update these parameters by your customers.
4) Run ```sh python Insurance_info.py ```
5) The info with customers' details will be provided on the screen. 
