from datetime import datetime

class Policyholder:
    def __init__(self, name, age, registration_date):
        self.name = name
        self.age = age
        self.registration_date = datetime.strptime(registration_date, "%d/%m/%Y")
        self.active = self.registration_date >= datetime.strptime("23/02/2025", "%d/%m/%Y")
        self.policies = []

    def register_policy(self, policy):
        if self.active:
            self.policies.append(policy)
            print(f"{policy.name} was registred for the policyholder {self.name}.")
        else:
            print(f"Can't be registred. Account for {self.name} is expired. Please, send your request to support team.")

    def suspend(self):
        self.active = False
        print(f"Account for {self.name} is expired. Please, send ypur request to support team for the acoount reopening.")

    def reactivate(self):
        self.active = True
        print(f"Account for {self.name} is active again.")

    def display_info(self):
        status = "Active" if self.active else "Expired"
        print(f"Policyholder, name: {self.name}, Age: {self.age}, State: {status}, Registration date: {self.registration_date.strftime('%d/%m/%Y')}")
        if self.active:
            print("Policy:")
            for policy in self.policies:
                print(f"  - {policy.name} ({policy.price} $)")