from Policyholder import Policyholder
from PolicyProduct import PolicyProduct
from Payment import Payment

# Print results:
policy1 = PolicyProduct("Health insurance", 5000)
policy2 = PolicyProduct("Insurance for the properties (flat, house, land)", 10500)
policy3 = PolicyProduct("Insurance for the domestic pets", 2000)

policyholder1 = Policyholder("Dart Wayder", 45, "10/12/2024")
policyholder2 = Policyholder("Harry Potter", 17, "26/02/2025")
policyholder3 = Policyholder("Tom Cat", 9, "13/01/2025")

payment1 = Payment(policyholder1, policy1.price)
payment2 = Payment(policyholder2, policy2.price)
payment3 = Payment(policyholder3, policy3.price)

policyholder1.register_policy(policy1)
policyholder2.register_policy(policy2)
policyholder3.register_policy(policy3)

payment1.process_payment()
payment2.process_payment()
payment3.process_payment()

print("\nCustomer details:")
policyholder1.display_info()
policyholder2.display_info()
policyholder3.display_info()

#Reminders
payment1.send_reminder()
payment2.send_reminder()
payment3.send_reminder()

#Total count of active and non active customers
policyholders = [policyholder1, policyholder2, policyholder3]
active_count = sum(1 for p in policyholders if p.active)
non_active_count = len(policyholders) - active_count
print(f"\nTotal amount of active customers: {active_count}")
print(f"Total amount of non active customers: {non_active_count}")