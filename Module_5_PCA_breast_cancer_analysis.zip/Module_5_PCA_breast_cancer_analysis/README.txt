PCA Breast Cancer Analysis

Ther script applies for PCA Breast cancer dataset from sklearn. 
The key of the script - identify key values, reduce data and visualize important factors. 
The results will be saved in the xlsx files.

For phyton, the script creates graphs that show how much information each component carries, which the most important and how data looks after dimensionality reduction.
It also saves results in the Excel files, provides tables, creates vizualization.

For R, the script performs the same PCA analysis and generates vizualization of the differences between tumor types.

Python 3.x should be installed.
R (4.x+) should be installed
Necessary Python packages should be installed:
pip install numpy pandas matplotlib seaborn scikit-learn openpyxl

For run the scripts:
1) Save PCA_breast_cancer_analysis.py
2) Save PCA_breast_cancer_analysis.R
3) Run ```sh python PCA_breast_cancer_analysis.py ``` 
4) Run sourse ("PCA_breast_cancer_analysis.R")