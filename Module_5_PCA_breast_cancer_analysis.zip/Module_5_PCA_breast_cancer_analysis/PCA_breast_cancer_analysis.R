# Upload necessary packages if not exist
if (!requireNamespace("ggplot2", quietly = TRUE)) install.packages("ggplot2")
if (!requireNamespace("mlbench", quietly = TRUE)) install.packages("mlbench")

# Upload necessary libraries if not exist
library(ggplot2)
library(mlbench)

# Upload data about breast cancer
data(BreastCancer, package = "mlbench")
data <- BreastCancer

data <- data[, -1]  

# Standart the elements
data[, -10] <- lapply(data[, -10], function(x) as.numeric(as.character(x)))

# Delete empty data 
data <- na.omit(data)

# Leave unique values
data <- data[, sapply(data, function(x) length(unique(x)) > 1)]

# Use PCA for minimization to 2 components
pca_result <- prcomp(data[, -10], center = TRUE, scale. = TRUE)

# Create a table with 2 the most valuable factors(components) and vizualize the results
pca_2d_df <- as.data.frame(pca_result$x[, 1:2])
colnames(pca_2d_df) <- c("PCA_1", "PCA_2")

# Add info for Benign and Malignant tumors
pca_2d_df$TumorType <- as.factor(data$Class)

ggplot(pca_2d_df, aes(x = PCA_1, y = PCA_2, color = TumorType)) +
  geom_point(alpha = 0.7) +
  labs(title = "The average values depends on Benign and Malignant tumors", x = "PCA 1", y = "PCA 2") +
  theme_minimal()
