import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.datasets import load_breast_cancer

# I decided to prepare info about breast cancer. 
# Like a first step, necessary to upload data about breast cancer from sklearn.
# This dataset includes info about medical research and results of breast cancer treatment, which helps for analysis of risk and % of success.
# Dependences can help to involve new investors.

cancer = load_breast_cancer()

#Shaow data like DataFrame
data = pd.DataFrame(cancer.data, columns = cancer.feature_names)

# Necessary to standart all attribute/element, cos they have different way of collecting (like ex mm, %, etc.). 
scaler = StandardScaler()
data_scaled = scaler.fit_transform(data)

#By PCA try to pick main fartors of data, that include maximum of information
pca = PCA()
pca_results = pca.fit_transform(data_scaled)

#Check, how many info includes each new components (main components) for understanding how many valuable info they include.
explained_variance = pca.explained_variance_ratio_

#For better vizualization and analisis need to leave min factors but with the most valuable info.
#As main factors picked factors that saved 95% of the info.
cumulative_variance = np.cumsum(explained_variance)

#Create vizualization, that show which are factors are more valuable and for wich factors info grow isn't high.
plt.figure(figsize=(10, 5))
plt.plot(range(1, len(explained_variance) + 1), cumulative_variance, marker='o', linestyle='-')
plt.xlabel('Count of factors') # How many we'd like to leave
plt.ylabel('Percentage of saved info')
plt.title('Main factors')
plt.grid()
plt.show()

num_factors = np.argmax(cumulative_variance >= 0.95) + 1
print(f"Enough to leave {num_factors} factors for saving 95% of information.")

#Delete all unnecessary factors and leave just main.
pca_optimal = PCA(n_components=num_factors)
pca_optimal_results = pca_optimal.fit_transform(data_scaled)

#Create a table with the most valuable characteristics of breast cancer for the diagnoses
factor_table = pd.DataFrame(pca_optimal.components_, columns=cancer.feature_names, index=[f'Factor {i+1}' for i in range(num_factors)])

#Vizualization for these parameters
for i in range (num_factors):
    plt.figure(figsize=(10, 5))
    colors = sns.color_palette("husl", len(cancer.feature_names))
    plt.bar(cancer.feature_names, factor_table.iloc[i], color=colors)
    plt.xticks(rotation=90)
    plt.xlabel('Parameters')
    plt.ylabel('Valuability')
    plt.title(f'The most valuable parameters for the breast cancer diagnoses by Factor {i+1}')
    plt.show()


print("The most valuable parameters for the breast cancer diagnoses:")
print(factor_table)

#Use PCA for minimization to 2 components
pca_2d = PCA(n_components=2)
pca_2d_result = pca_2d.fit_transform(data_scaled)
pca_2d_df = pd.DataFrame(pca_2d_result, columns=['PCA_1', 'PCA_2'])

#Show the table with 2 the most valuable factors(components) and vizualize the results
print("Two main factors:")
print(pca_2d_df.head())

plt.figure(figsize=(8,6))
plt.scatter(pca_2d_df['PCA_1'], pca_2d_df['PCA_2'], alpha=0.5)
plt.xlabel('First main factor')
plt.ylabel('Second main factor')
plt.title(f'Dependences of 2 the most valuable factors')
plt.grid()
plt.show()

#Save results in the Excel files

factor_table.to_excel("PCA_breast_cancer_results.xlsx")
pca_2d_df.to_excel("PCA_2D_results.xlsx", index=False)
print("The results are saved in the PCA_breast_cancer_results.xlsx. and PCA_2D_results.xlsx")

#For Bonus Point (Optional)
#The table of average PCA_1 for Benign and Malignant tumors
pca_2d_df['target'] = cancer.target # where 0 - beging, 1 - malignant
avg_pca1_by_class = pca_2d_df.groupby('target')['PCA_1'].mean().rename({0: 'Beging', 1: 'Malignant'})
print("The average values for the Factor 1 depends on Benign and Malignant tumors")
print(avg_pca1_by_class)